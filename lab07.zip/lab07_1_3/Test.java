package lab07_1_3;

public class Test {
    public static void main(String[] args) {
        MovablePoint movable1 = new MovablePoint(7, 6, 5, 4);
        movable1.moveLeft();
        movable1.moveDown();
        movable1.moveRight();

        MovablePoint movable2 = new MovablePoint(1, 2, 3, 4);
        movable2.moveRight();
        movable2.moveDown();
        movable2.moveLeft();
        movable2.moveUp();
    }
}
