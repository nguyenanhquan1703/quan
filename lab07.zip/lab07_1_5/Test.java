package lab07_1_5;

public class Test {
    public static void main(String[] args) {
        ResizableCircle resizableCircle1 = new ResizableCircle(2.2);
        System.out.println(resizableCircle1);
        resizableCircle1.toString();
        System.out.println(resizableCircle1);

        ResizableCircle resizableCircle2 = new ResizableCircle(10.9);
        resizableCircle2.getArea();
        System.out.println(resizableCircle2);

        ResizableCircle resizableCircle4 = new ResizableCircle(5.5);
        resizableCircle4.getPerimeter();
        System.out.println(resizableCircle4);
    }
}
