package lab07_1_5;

public interface Resizable {
    public void resize(int percent);
}
