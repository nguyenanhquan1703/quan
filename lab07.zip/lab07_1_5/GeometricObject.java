package lab07_1_5;

public interface GeometricObject {
    public abstract double getPerimeter();

    public abstract double getArea();
}
