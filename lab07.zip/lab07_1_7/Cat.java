package lab07_1_7;

public class Cat extends Animal {
    @Override
    public void greeting() {
        System.out.println("Meow");
    }
}
