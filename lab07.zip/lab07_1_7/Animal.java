package lab07_1_7;

public abstract class Animal {
    public abstract void greeting();
}
