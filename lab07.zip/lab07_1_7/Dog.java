package lab07_1_7;

public class Dog extends Animal {
    @Override
    public void greeting() {
        System.out.println("Woof");
    }

    public void greets(lab07_1_6.Dog another) {
        System.out.println("Woooof");
    }
}
