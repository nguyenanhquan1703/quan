package lab07_1_4;

public class Test {
    public static void main(String[] args) {
        Movable m2 = new MovableCircle(1, 2, 3, 4, 20);
        System.out.println(m2);
        m2.moveRight();
        System.out.println(m2);

//        Movable m3 = new MovablePoint(1,2,3,4);
//        System.out.println(m3);
//        m3.moveLeft();
//        System.out.println(m3);
    }
}
