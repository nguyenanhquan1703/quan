package lab07_1_2;

public class Test {
    public static void main(String[] args) {
        Circle circle1 = new Circle(2.2);
        System.out.println(circle1);
        System.out.println(circle1.getArea());
        System.out.println(circle1.getPerimeter());
        System.out.println(circle1.toString());

//        Circle circle2 = new Rectangle(1.2, 1.3);
//        System.out.println(circle2.getPerimeter());

        Rectangle rectangle1 = new Rectangle(5.5, 8.5);
        System.out.println(rectangle1.getArea());
        System.out.println(rectangle1.toString());
        System.out.println(rectangle1.getPerimeter());
    }
}
