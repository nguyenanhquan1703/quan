package lab07_1_2;

public interface GeometricObject {
    public abstract double getArea();

    public abstract double getPerimeter();

}
