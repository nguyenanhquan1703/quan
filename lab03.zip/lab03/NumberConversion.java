import java.util.Scanner;

public class NumberConversion {
    public static String toRadix(String in, int inRadix, int outRadix) {
        if (inRadix == outRadix) {
            return in;
        }
        if (outRadix == 10) {
            return toDec(in, inRadix);
        }
        if (inRadix == 10) {
            return decToN(in, outRadix);
        }
        String dec = toDec(in, inRadix);
        return decToN(dec, outRadix);
    }

    public static String decToN(String in, int outRadix) {
        int dec = Integer.parseInt(in);
        String res = "";
        while (dec > 0) {
            int tmp = dec % outRadix;
            if (tmp < 10) {
                res = tmp + res;
            } else {
                res = (char) (tmp + 55) + res;
            }
            dec /= outRadix;
        }
        return res;
    }

    public static String toDec(String in, int inRadix) {
        in = in.toUpperCase();
        int res = 0;
        for (int i = 0; i < in.length(); i++) {
            char c = in.charAt(i);
            if (c >= '0' && c <= '9') {
                int d = c - '0';
                res = res * inRadix + d;
            } else if (c >= 'A' && c <= 'F') {
                int d = c - 'A' + 10;
                res = res * inRadix + d;
            }
        }
        return res + "";
    }

//    public static String hexToBin(String in) {
//        in = in.toUpperCase();
//        final String[] HEX_BITS = {
//                "0000", "0001", "0010", "0011",
//                "0100", "0101", "0110", "0111",
//                "1000", "1001", "1010", "1011",
//                "1100", "1101", "1110", "1111"
//        };
//        String res = "";
//        for (int i = 0; i < in.length(); i++) {
//            char c = in.charAt(i);
//            if (c >= '0' && c <= '9') {
//                res += HEX_BITS[c - '0'];
//            } else if (c >= 'A' && c <= 'F') {
//                res += HEX_BITS[c - 'A' + 10];
//            }
//        }
//        return res;
//    }
//
//    public static String octToBin(String in) {
//        in = in.toUpperCase();
//        final String[] OCT_BITS = {
//                "000", "001", "010", "011",
//                "100", "101", "110", "111",
//        };
//        String res = "";
//        for (int i = 0; i < in.length(); i++) {
//            res += OCT_BITS[in.charAt(i) - '0'];
//        }
//        return res;
//    }



    public static void main(String[] args) {
        System.out.println(toRadix("11", 2, 10));
        System.out.println(toRadix("11", 8, 10));
        System.out.println(toRadix("11", 16, 10));
        System.out.println(toRadix("A1B2", 16, 2));
        System.out.println(toRadix("11", 8, 2));
        System.out.println(toRadix("20", 10, 2));
        System.out.println(toRadix("20", 10, 8));
        System.out.println(toRadix("20", 10, 16));
        System.out.println(toRadix("A", 16, 8));
        System.out.println(toRadix("10", 8, 16));
//        Scanner in = new Scanner(System.in);
//        System.out.print("Enter a number and radix: ");
//        String number = in.nextLine();
//        System.out.print("Enter the input radix: ");
//        int inRadix = in.nextInt();
//        System.out.print("Enter the output radix: ");
//        int outRadix = in.nextInt();
//        in.close();
//        System.out.print("\"" + number + "\" in radix " + inRadix + " is \"" + toRadix(number, inRadix, outRadix) + "\" in radix " + outRadix + ".");
    }
}
