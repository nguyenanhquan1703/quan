package Lab06_1_4;

public class Test {
    public static void main(String[] args) {
        Square s1 = new Square(5);
        System.out.println(s1.getArea());
        Square s2 = new Square(6);
        System.out.println(s2.toString());
    }
}
