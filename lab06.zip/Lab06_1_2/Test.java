package Lab06_1_2;

public class Test {
    public static void main(String[] args) {
        Student s1 = new Student("ha", "hanoi", "abc", 2012, 5);
        System.out.println(s1.getAddress());
    }
}
