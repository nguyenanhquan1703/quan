package Lab06_1_5;

public class Test {
    public static void main(String[] args) {
        Dog d1 = new Dog("gau");
        System.out.println(d1.toString());
    }
}
