package Lab06_1_3;

public class Test {
    public static void main(String[] args) {
        Point3D p1 = new Point3D(2, 3, 4);
        System.out.println(p1.toString());
    }
}
