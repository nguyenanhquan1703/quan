package exercises1_class1_8;

public class TestMyPolynomial {
	public static void main(String[] args) {
		
		double[] coeffs1 = {1.2, 3.4, 5.6, 7.8};
        double[] coeffs2 = {1.1, 2.2, 3.3, 4.4};
        MyPolynomial polynomial1 = new MyPolynomial(coeffs1);
        MyPolynomial polynomial2 = new MyPolynomial(coeffs2);

        System.out.println(polynomial1);
        System.out.println(polynomial2.getDegree());

        System.out.println(polynomial1.evaluate(2));
        System.out.println(polynomial2.add(polynomial1));
        System.out.println(polynomial1.multiply(polynomial2));
	}
}
