package exercises1_class1_4;

public class TestEmplyee {

    public static void main(String[] args) {
        Emplyee emplyee1 = new Emplyee(8, "Peter", "Tan", 2500);
        System.out.println(emplyee1);

        emplyee1.setSalary(999);
        System.out.println(emplyee1);
        System.out.println("id is: " + emplyee1.getId());
        System.out.println("fistname is: " + emplyee1.getFirstName());
        System.out.println("lastname is: " + emplyee1.getLastName());
        System.out.println("salary is: " + emplyee1.getSalary());

        System.out.println("name is: " + emplyee1.getName());
        System.out.println("anual salary is: " + emplyee1.getAnnuaSalary());

        System.out.println(emplyee1.raiseSalary(10));
        System.out.println(emplyee1);
    }

}

