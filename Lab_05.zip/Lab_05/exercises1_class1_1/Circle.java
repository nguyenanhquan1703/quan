package exercises1_class1_1;

import java.rmi.ConnectIOException;

public class Circle {
    //private double radius = 1.0;

    private double radius;
    private String color = "red";

    public Circle() {
    }

    public Circle(double radius) {
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    /*public void setRadius(double radius) {
        this.radius = radius;
    }*/

    public double getArea() {
        return Math.PI * radius * radius;
    }

    public double getCircumference() {
        return 2 * Math.PI * radius;
    }

    public Circle(double r, String c) {
        radius = r;
        color = c;
    }

    public String getColor() {
        return color;
    }

    /*public void setRadius(double newRadius) {
        newRadius = radius;
    }*/

    public void setColor(String newColor) {
        newColor = color;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    @Override
    /*public String toString() {
        return "Circle[radius=" + radius + "]";
    }*/

    public String toString() {
        return "Circle[radius = " + radius + "color" + color + "]";
    }
}
