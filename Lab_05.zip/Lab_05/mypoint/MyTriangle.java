package mypoint;

public class MyTriangle {
	private MyPoint vertices1;
	private MyPoint vertices2;
	private MyPoint vertices3;
	
	public MyTriangle(int x1, int y1, int x2, int y2, int x3, int y3) {
		super();
		vertices1 = new MyPoint(x1, y1);
		vertices2 = new MyPoint(x2, y2);
		vertices3 = new MyPoint(x3, y3);
		
	}
	public MyTriangle(MyPoint vertices1, MyPoint vertices2, MyPoint vertices3) {
		super();
		this.vertices1 = vertices1;
		this.vertices2 = vertices2;
		this.vertices3 = vertices3;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "MyTriangle[vertices1 = ( " + vertices1 
				+ "), vertices2 = ( " + vertices2 
				+ "), vertices3 = ( " + vertices3 + " )]" ;
	}
	
	public double getPerimeter() {
		 return vertices1.distance(vertices2) + vertices2.distance(vertices3) + vertices3.distance(vertices1);
	}
	
	public String getType() {
        double type1 = vertices1.distance(vertices2);
        double type2 = vertices2.distance(vertices3);
        double type3 = vertices3.distance(vertices1);

        if (type1 == type2 && type2 == type3 && type3 == type1) {
            return "Equilateral";
        } else if (type1 == type2 || type2 == type3 || type3 == type1) {
            return "Isosceles";
        } else {
            return "Scalene";
        }
    }
}
