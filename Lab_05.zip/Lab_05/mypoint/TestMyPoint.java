package mypoint;

public class TestMyPoint {

	public static void main(String[] args) {
		
		MyPoint point1 = new MyPoint(3, 4);
		MyPoint point2 = new MyPoint(5, 6);
		System.out.println(point1.distance(5, 6));
		System.out.println(point1.distance(point2));
		System.out.println(point1.distance());
		
		
	}

}
