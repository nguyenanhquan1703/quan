package exercises1_class1_7;

import java.util.Scanner;

public class MyComplexApp {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
        System.out.print("Enter complex number 1 (real and imaginary part): ");
        double firstReal = input.nextDouble();
        double firstImaginary = input.nextDouble();
        input.nextLine();
        System.out.print("Enter complex number 2 (real and imaginary part): ");
        double secondReal = input.nextDouble();
        double secondImaginary = input.nextDouble();
        input.nextLine();
        input.close();
        System.out.println();

        MyComplex myComplex1 = new MyComplex(firstReal, firstImaginary);
        MyComplex myComplex2 = new MyComplex(secondReal, secondImaginary);

        System.out.println("Number 1 is: " + myComplex1);
        if(!myComplex1.isReal()) {
            System.out.println(myComplex1 + " is NOT a pure real number");
        } else {
            System.out.println(myComplex1 + " is a pure real number");
        }
        if(!myComplex1.isImaginary()) {
            System.out.println(myComplex1 + " is NOT a pure imaginary number");
        } else {
            System.out.println(myComplex1 + " is a pure imaginary number");
        }
        System.out.println();

        System.out.println("Number 2 is: " + myComplex2);
        if(!myComplex2.isReal()) {
            System.out.println(myComplex2 + " is NOT a pure real number");
        } else {
            System.out.println(myComplex2 + " is a pure real number");
        }
        if(!myComplex2.isImaginary()) {
            System.out.println(myComplex2 + " is NOT a pure imaginary number");
        } else {
            System.out.println(myComplex2 + " is a pure imaginary number");
        }
        System.out.println();

        if(!myComplex1.equals(myComplex2)) {
            System.out.println(myComplex1 + " is NOT equal to " + myComplex2);
        } else {
            System.out.println(myComplex1 + " is equal to " + myComplex2);
        }
        
        System.out.println(myComplex1 + " + " + myComplex2 + " = " + myComplex1.addNew(myComplex2));
        System.out.println(myComplex1 + " - " + myComplex2 + " = " + myComplex1.subtractNew(myComplex2));
	}
}