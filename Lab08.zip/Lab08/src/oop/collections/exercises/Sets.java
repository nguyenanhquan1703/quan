package oop.collections.exercises;

import java.util.*;

public class Sets {
    public static Set<Integer> intersectionManual(Set<Integer> first, Set<Integer> second) {
        Set<Integer> inter = new HashSet<>();
        for (int i : first) {
            for (int j : second) {
                if (i == j) {
                    inter.add(i);
                }
            }
        }
        return inter;
    }

    public static Set<Integer> unionManual(Set<Integer> first, Set<Integer> second) {
        Set<Integer> inter = new HashSet<>();
        for (int i : first) {
            inter.add(i);
        }
        for (int j : second) {
            inter.add(j);
        }
        return inter;
    }

    public static Set<Integer> intersection(Set<Integer> first, Set<Integer> second) {
        Set<Integer> res = new HashSet<>(first);
        res.retainAll(second);
        return res;
    }

    public static Set<Integer> union(Set<Integer> first, Set<Integer> second) {
        Set<Integer> res = new HashSet<>(first);
        res.addAll(second);
        return res;
    }

    public static List<Integer> toList(Set<Integer> source) {
        return new ArrayList<>(source);
    }

    public static List<Integer> removeDuplicates(List<Integer> source) {
//        List<Integer> res = new ArrayList<>();
//        for (int i : source) {
//            if (!res.contains(i)) {
//                res.add(i);
//            }
//        }
//        return res;
        return new ArrayList<>(new HashSet<>(source));
    }

    public static List<Integer> removeDuplicatesManual(List<Integer> source) {
        return new ArrayList<>(new HashSet<>(source));
    }

    public static String firstRecurringCharacter(String s) {
        if (s == null || s.length() == 0) {
            return null;
        }

        Set<String> set = new HashSet<>();
        for (int i = 0; i < s.length(); i++) {
            String res = s.charAt(i) + "";
            if (set.contains(res)) {
                return res;
            }
            set.add(res);
        }
        return null;
    }

    public static Set<Character> allRecurringCharacter(String s) {
        Set<Character> set = new HashSet<>();
        Set<Character> res = new HashSet<>();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (set.contains(c)) {
                res.add(c);
            } else {
                set.add(c);
            }
        }
        return res;
    }

    public static Integer[] toArray(Set<Integer> source) {
        //return source.toArray(new Integer[0]);
        return (Integer[]) source.toArray();
    }

    public static int getFirst(TreeSet<Integer> source) {
        return source.first();
    }

    public static int getLast(TreeSet<Integer> source) {
        return source.last();
    }

    public static int getGreater(TreeSet<Integer> source, int value) {
        return source.higher(value);
    }
}

