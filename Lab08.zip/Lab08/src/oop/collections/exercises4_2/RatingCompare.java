package oop.collections.exercises4_2;

import java.util.Comparator;

public class RatingCompare implements Comparator<Movie> {
    @Override
    public int compare(Movie left, Movie right) {
        return left.compareTo(right);
    }
}
