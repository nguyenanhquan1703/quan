package iterator.demoprogram;

public interface Iterable {
    Iterator getIterator();
}
