package decorator.demoprogram.icecream;

public class VanillaIceCream implements IceCream {
    @Override
    public String getDescription() {
        return "Vanilla ice cream";
    }
}
