package decorator.demoprogram.icecream;

public class ChocolateIceCream implements IceCream {
    @Override
    public String getDescription() {
        return "Chocolate ice cream";
    }
}
