package decorator.demoprogram.icecream;

public class StrawberryIceCream implements IceCream {
    @Override
    public String getDescription() {
        return "Strawberry ice cream";
    }
}
