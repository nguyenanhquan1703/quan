package decorator.demoprogram.icecream;

public interface IceCream {
    String getDescription();
}
