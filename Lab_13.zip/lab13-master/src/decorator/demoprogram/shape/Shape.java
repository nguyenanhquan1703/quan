package decorator.demoprogram.shape;

public interface Shape {
    void draw();
}
