package com.patterns.iterator;

public interface Menu {
    Iterator createIterator();
}
