package com.patterns.iterator.employee;

public interface Iterator {
    boolean hasNext();

    Object next();
}
