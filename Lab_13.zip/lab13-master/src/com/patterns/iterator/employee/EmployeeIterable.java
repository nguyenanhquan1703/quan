package com.patterns.iterator.employee;

public interface EmployeeIterable {
    Iterator getIterator();
}
