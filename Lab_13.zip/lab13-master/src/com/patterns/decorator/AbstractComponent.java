package com.patterns.decorator;

public abstract class AbstractComponent {
    public abstract void execute();
}
