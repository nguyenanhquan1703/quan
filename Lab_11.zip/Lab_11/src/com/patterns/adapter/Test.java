package com.patterns.adapter;

public class Test {
    public static void main(String[] args) {
        RoundHole hole = new RoundHole(5);
        RoundPeg peg = new RoundPeg(5);
        System.out.println(hole.fits(peg));

        SquarePeg squarePeg1 = new SquarePeg(5);
        SquarePeg squarePeg2 = new SquarePeg(10);
        //System.out.println(squarePeg1.fits(squarePeg2));

        SquarePegAdapter squarePegAdapter1 = new SquarePegAdapter(squarePeg1);
        SquarePegAdapter squarePegAdapter2 = new SquarePegAdapter(squarePeg2);
        System.out.println(hole.fits(squarePegAdapter1));
        System.out.println(hole.fits(squarePegAdapter2));
    }


}
