package com.patterns.singleton;

public class Application {
    public static void main(String[] args) {
        Database database1 = Database.getInstance();
        database1.query("SELECT * FROM K65A1");
        database1.query("SELECT * FROM K65A3 WHERE DIEM = 8");
        database1.query("SELECT Ten FROM K65A2 WHERE LOP = A2");

        Database database2 = Database.getInstance();
        database2.query("SELECT * FROM K64A5");
        database2.query("CREATE TABLE");
        database2.query("database1");

        System.out.println(database1 == database2);
    }
}
