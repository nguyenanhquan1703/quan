package com.patterns.strategy;

public interface Strategy {
    double execute(double a, double b);

}
