package com.patterns.strategy;

public class ConcreteStrategyMultiply implements Strategy {
    public double execute(double a, double b) {
        return a * b;
    }
}
