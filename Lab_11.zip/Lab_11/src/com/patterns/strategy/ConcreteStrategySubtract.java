package com.patterns.strategy;

public class ConcreteStrategySubtract implements Strategy {
    public double execute(double a, double b) {
        return a - b;
    }
}
