package sort;

public interface ISort {

    public abstract int sort(int[] data);
}

