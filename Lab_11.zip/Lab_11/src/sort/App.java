package sort;

import java.util.*;

public class App {

    public static void main(String[] args) {

        SortStrategy sortArray = SortStrategy.getInstance();
        int numSwap = 0;

        System.out.println("Using Bubble Sort Algorithm: ");
        int[] bubbleSortArray = new int[5];
        generateArray(bubbleSortArray);
        sortArray.setSortee(new BubbleSort());
        System.out.print("Before sorting: ");
        printArray(bubbleSortArray);

        numSwap = sortArray.sort(bubbleSortArray);
        System.out.print("After sorting: ");
        printArray(bubbleSortArray);
        System.out.println("Number of swap: " + numSwap);

        System.out.println("\nUsing Selection Sort Algorithm: ");
        int[] selectionSortArray = new int[5];
        generateArray(selectionSortArray);
        sortArray.setSortee(new SelectionSort());
        System.out.print("Before sorting: ");
        printArray(selectionSortArray);

        numSwap = sortArray.sort(selectionSortArray);
        System.out.print("After sorting: ");
        sortArray.sort(selectionSortArray);
        printArray(selectionSortArray);
        System.out.println("Number of swap: " + numSwap);

        System.out.println("\nUsing Insertion Sort Algorithm: ");
        int[] insertionSortArray = new int[5];
        generateArray(insertionSortArray);
        sortArray.setSortee(new InsertionSort());
        System.out.print("Before sorting: ");
        printArray(insertionSortArray);

        numSwap = sortArray.sort(insertionSortArray);
        System.out.print("After sorting: ");
        sortArray.sort(insertionSortArray);
        printArray(insertionSortArray);
        System.out.println("Number of swap: " + numSwap);
    }

    public static void generateArray(int[] array) {
        final int MAX = 100;
        final int MIN = 0;
        Random ran = new Random();
        for (int i = 0; i < array.length; i++) {
            array[i] = ran.nextInt(MAX - MIN) + MIN;
        }
    }

    public static void printArray(int[] array) {
        StringBuilder result = new StringBuilder();
        result.append("[");
        for (int i = 0; i < array.length; i++) {
            if (i == array.length - 1) {
                result.append(array[i]);
            } else {
                result.append(array[i] + " ");
            }
        }
        result.append("]");
        System.out.println(result.toString());
    }
}

