package ball;

public class TestBall {
    public static void main(String[] args) {
        Ball ball1 = Ball.getInstance("red");
        System.out.println(ball1.getColor());

        Ball ball2 = Ball.getInstance("green");
        System.out.println(ball2.getColor());

        System.out.println(ball1 == ball2);
    }
}
