import java.util.Scanner;

public class GradesStatistics {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter the number of students: ");
        int numStudents = in.nextInt();
        int[] arr = new int[numStudents];
        int min = 100, max = 0;
        double average = 0;
        for (int i = 0; i < numStudents; i++) {
            System.out.print("Enter the grade of student " + (i + 1) + ": ");
            arr[i] = in.nextInt();
            average += arr[i];
            if (min > arr[i]) {
                min = arr[i];
            }
            if (max < arr[i]) {
                max = arr[i];
            }
        }
        in.close();
        average /= numStudents;
        System.out.printf("The average is: %.2f\n", average);
        System.out.println("The minimum is: " + min);
        System.out.println("The maximum is: " + max);
    }
}
