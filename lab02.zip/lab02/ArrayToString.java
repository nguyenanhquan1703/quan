import java.util.Arrays;

public class ArrayToString {
    public static String arrayToString(int[] array) {
        if (array == null) {
            return "null";
        }
        String s = "[";
        for (int i = 0; i < array.length - 1; i++) {
            s += array[i] + ", ";
        }
        if (array.length > 0) {
            s += array[array.length - 1];
        }
        s += "]";
        return s;
    }

    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5};
        System.out.println(arrayToString(array));
        System.out.println(Arrays.toString(array));
    }
}
