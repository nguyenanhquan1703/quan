public class Swap {
    public static boolean swap(int[] array1, int[] array2) {
        if (array1 == null) {
            if (array2 == null) {
                return true;
            }
            return false;
        }
        if (array2 == null) {
            return false;
        }
        if (array1.length != array2.length) {
            return false;
        }
        for (int i = 0; i < array1.length; i++) {
            int tmp = array1[i];
            array1[i] = array2[i];
            array2[i] = tmp;
        }
        return true;
    }

    public static void main(String[] args) {
        int[] array1 = {1, 2, 3, 4, 5};
        int[] array2 = {6, 7, 8, 9, 10};
        int[] array3 = {1, 2, 3};
        System.out.println(swap(array1, array3));
        System.out.println(swap(array1, array2));
        Print.print(array1);
        Print.print(array2);
        System.out.println(swap(null, null));
        System.out.println(swap(array1, null));
    }
}
