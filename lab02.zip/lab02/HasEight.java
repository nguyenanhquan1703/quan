import java.util.Scanner;

public class HasEight {
    public static boolean hasEight(int number) {
        String s = number + "";
        return s.indexOf('8') > -1;
    }

    public static void main(String[] args) {
        final int SENTINEL = -1;
        Scanner in = new Scanner(System.in);
        int sumNumberHasEight = 0;
        int number = 0;
        while (number != SENTINEL) {
            if (hasEight(number)) {
                sumNumberHasEight += number;
            }
            System.out.print("Enter a positive integer (or -1 to end): ");
            number = in.nextInt();
        }
        System.out.print("The magic sum is: " + sumNumberHasEight);
    }
}
