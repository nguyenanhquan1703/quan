public class CopyOf {
    public static int[] copyOf(int[] array) {
        if (array == null) {
            return null;
        }
        int[] arr = new int[array.length];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = array[i];
        }
        return arr;
    }

    public static int[] copyOf(int[] array, int newLength) {
        if (array == null) {
            return null;
        }
        int[] arr = new int[newLength];
        for (int i = 0; i < Math.min(newLength, array.length); i++) {
            arr[i] = array[i];
        }
        return arr;
    }

    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5};
        Print.print(copyOf(array));
        Print.print(copyOf(null));
        Print.print(copyOf(array, 0));
        Print.print(copyOf(array, 10));
    }
}
