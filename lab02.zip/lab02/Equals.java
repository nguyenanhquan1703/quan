public class Equals {
    public static boolean equals(int[] array1, int[] array2) {
        if (array1 == null) {
            if (array2 == null) {
                return true;
            }
            return false;
        }
        if (array2 == null) {
            return false;
        }
        if (array1.length != array2.length) {
            return false;
        }
        for (int i = 0; i < array1.length; i++) {
            if (array1[i] != array2[i]) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        int[] array1 = {1, 2, 3, 4, 5};
        int[] array2 = {1, 2, 3, 4, 5};
        System.out.println(equals(array1, array2));
        System.out.println(equals(array1, null));
        System.out.println(equals(null, null));
    }
}
