package com.oop.collections.phonebook;

public class TestApp {
    public static void main(String[] args) {
        PhoneBook pb = new PhoneBookMap();

        pb.addPerson(new Student("Nicola", "Bicocchi", "123542"));
        pb.addPerson(new Student("Marco", "Rizzo", "525265"));
        pb.addPerson(new Student("Luisa", "Poppi", "526544"));

        System.out.println(pb.searchByName("Marco"));
        System.out.println(pb.searchByLastname("Poppi"));
        System.out.println(pb.searchByNumber("525265"));

        System.out.println(pb.searchByNumber("44557"));

        pb.deleteByNumber("525265");
        System.out.println(pb.searchByLastname("Poppi"));
    }
}
