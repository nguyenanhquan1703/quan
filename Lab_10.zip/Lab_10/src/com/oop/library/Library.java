package com.oop.library;

public class Library {
    Rent[] rents;

    public Rent getLongestRent() {
        long longest = 0;
        Rent longestRent = null;
        for (Rent rent : rents) {
            long time = rent.end.getTime() - rent.begin.getTime();
            if (time > longest) {
                longest = time;
                longestRent = rent;
            }
        }
        return longestRent;
    }

    public Library(Rent[] rents) {
        return;
    }
}
