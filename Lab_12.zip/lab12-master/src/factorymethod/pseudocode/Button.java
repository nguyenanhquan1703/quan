package factorymethod.pseudocode;

public interface Button {
    void render();
    void onClick();
}
