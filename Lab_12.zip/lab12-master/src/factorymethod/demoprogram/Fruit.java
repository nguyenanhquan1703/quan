package factorymethod.demoprogram;

public interface Fruit {
    void produceJuice();
}
