package factorymethod.demoprogram;

public class Apple implements Fruit {
    public void produceJuice() {
        System.out.println("Apple Juice");
    }
}