package factorymethod.demoprogram;

public class Banana implements Fruit {
    public void produceJuice() {
        System.out.println("Banana Juice");
    }
}