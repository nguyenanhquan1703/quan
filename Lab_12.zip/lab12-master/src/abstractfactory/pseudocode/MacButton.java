package abstractfactory.pseudocode;

public class MacButton implements Button {
    @Override
    public void paint() {
        System.out.println("MacButton");
    }
}
