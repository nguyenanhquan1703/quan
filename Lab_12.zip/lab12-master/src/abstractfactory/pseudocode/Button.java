package abstractfactory.pseudocode;

public interface Button {
    void paint();
}