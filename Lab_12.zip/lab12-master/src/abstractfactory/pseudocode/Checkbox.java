package abstractfactory.pseudocode;

public interface Checkbox {
    void paint();
}