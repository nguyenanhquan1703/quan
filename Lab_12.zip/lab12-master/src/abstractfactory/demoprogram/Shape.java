package abstractfactory.demoprogram;

public interface Shape {
    void draw();
}