package observer.pseudocode;

public interface EventListener {
    void update(String filename);
}
